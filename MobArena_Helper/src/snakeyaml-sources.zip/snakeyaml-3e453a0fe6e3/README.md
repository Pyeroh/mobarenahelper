SnakeYAML
=========

##YAML parser and emitter for Java

This is the official [SnakeYAML] mirror for those who prefer to use GIT.


## License

The SnakeYAML is licensed under [APL 2.0].

  [SnakeYAML]:          http://www.snakeyaml.org/
  [APL 2.0]:            http://www.apache.org/licenses/LICENSE-2.0


